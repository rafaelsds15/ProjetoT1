package com.example.locadoradegames;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private EditText nome,idade,email,telefone;
    private RadioButton masculino,feminino;
    private TextView resultadoNome,resultadoIdade,resultadoSexo,resultadoEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome=findViewById(R.id.editNome);
        idade=findViewById(R.id.editIdade);
        email=findViewById(R.id.editEmail);


        masculino=findViewById(R.id.radioButtonMasculino);
        feminino=findViewById(R.id.radioButtonFeminino);

        resultadoNome=findViewById(R.id.resultadoNome);
        resultadoIdade=findViewById(R.id.resultadoIdade);
        resultadoSexo=findViewById(R.id.resultadoSexo);
        resultadoEmail=findViewById(R.id.resultadoEmail);


        Button botaoCadastrar=findViewById(R.id.bt_Cadastrar);
        botaoCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            String editNome= nome.getText().toString();
            String editIdade= idade.getText().toString();
            String editEmail= email.getText().toString();





                if(editNome.isEmpty() || editIdade.isEmpty() || editEmail.isEmpty()){
                    Snackbar.make(v,text: "Preencha o nome, a idade e o Email",Snackbar.LENGTH_SHORT).show();

            }else{
                 RadioButtonSelecionado(v);


                }
            }
        });

    }
    private void RadioButtonSelecionado(View view){
        String editNome= nome.getText().toString();
        String editIdade= idade.getText().toString();
        String editEmail= email.getText().toString();

        if(feminino.isChecked()){
            resultadoNome.setText(editNome);
            resultadoIdade.setText(editIdade);
            resultadoEmail.setText(editEmail);
            resultadoSexo.setText("Sexo: Feminino");

        }else if(masculino.isChecked()){
            resultadoNome.setText(editNome);
            resultadoIdade.setText(editIdade);
            resultadoEmail.setText(editEmail);
            resultadoSexo.setText("Sexo: Masculino");
        }else{
            Snackbar.make(v,text: "Selecione o seu Sexo",Snackbar.LENGTH_SHORT).show();


        }
    }
}